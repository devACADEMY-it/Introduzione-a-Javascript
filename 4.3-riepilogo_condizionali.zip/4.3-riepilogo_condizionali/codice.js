/*
 * Introduzione a Javascript
 * Esempio riepilogativo: “Prezzi e sconti”
 *
 * Disponibile su devACADEMY.it
 */

var prezzo=100;
var tessera_punti=90;
var card="fidelity"; // fidelity, gold, no

// ogni 15 euro di spesa, il cliente guadagna punti:
// 3 punti (no card), 5 punti (fidelity), 8 punti (gold)

var incremento=3;

switch(card)
{
	case "fidelity":
		incremento=5;
		break;
	case "gold":
		incremento=8;
		break;
	case "no":
		incremento=3;

}

var nuovi_punti=Math.floor(prezzo/15*incremento);

document.write("Ha guadagnato "+nuovi_punti+" punti<br>");

tessera_punti+=nuovi_punti;

document.write("Ora possiede "+tessera_punti+" punti<br>");

if (tessera_punti>=100)
{
	prezzo*=0.8;
	tessera_punti-=100;
	document.write("Applichiamo uno sconto, ora ha "+tessera_punti+" punti<br>");

	var messaggio=(card=="no")?"Sottoscriva una nostra carta, conviene!<br>"
		: "Grazie di sceglierci ancora<br>";
	document.write(messaggio);
}
else
	document.write("Non possiamo applicare alcno sconto!<br>");

document.write("Prezzo finale: "+prezzo);