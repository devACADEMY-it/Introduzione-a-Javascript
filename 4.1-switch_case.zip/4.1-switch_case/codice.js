/*
 * Introduzione a Javascript
 * Switch
 *
 * Disponibile su devACADEMY.it
 */

var semaforo="marrone";

switch(semaforo)
{
	case "rosso":
		document.write("Ti devi fermare!! <br>");
		break;
	case "giallo":
		document.write("Inizia a rallentare...<br>");
	    break;
	case "verde":
		document.write("Via libera, puoi passare...<br>");
		break;
	default:
		document.write("Errore, colore errato...<br>");
}