/*
 * Introduzione a Javascript
 * Valori di default per argomenti
 *
 * Disponibile su devACADEMY.it
 */

function tabellina(x=2)
{
	/*if (x==undefined)
		document.write("Nessun valore fornito <br>");
	else*/
	   for(i=1; i<=10; i++)
		  document.write(i*x+"<br>");
}

tabellina(8);