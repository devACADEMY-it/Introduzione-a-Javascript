/*
 * Introduzione a Javascript
 * break e continue
 *
 * Disponibile su devACADEMY.it
 */

for (ind=0; ind<=40; ind+=2)
{
	if (ind%3!=0)
		continue;
	document.write(ind+"<br>");
}

/*for (ind=0; ; ind+=2)
{
	if (ind>24)
		break;
	document.write(ind+"<br>");
}*/
document.write("Fine programma<br>");