/*
 * Introduzione a Javascript
 * Realizzare funzioni
 *
 * Disponibile su devACADEMY.it
 */

var messaggio=function(){

	document.write("Funzione anonima <br>");

}

var altroMessaggio=messaggio;

function ciaoMondo()
{
	document.write("Ciao mondo <br>");

}

ciaoMondo();
ciaoMondo();
ciaoMondo();

altroMessaggio();