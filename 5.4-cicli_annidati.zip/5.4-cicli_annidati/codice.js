/*
 * Introduzione a Javascript
 * Esempio riepilogo: “Calcolo delle tabelline”
 *
 * Disponibile su devACADEMY.it
 */

var valore=1;

while (valore<=10)
{
	var ind=1;

	while(ind<=10)
	{
		document.write(ind*valore);
		document.write("\t");
		ind++;
	}

	document.write("<br>");
	valore++;
}