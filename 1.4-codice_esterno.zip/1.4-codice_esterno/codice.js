/*
 * Introduzione a Javascript
 * Javascript in file esterni
 *
 * Disponibile su devACADEMY.it
 */

document.write("Hello world!!");