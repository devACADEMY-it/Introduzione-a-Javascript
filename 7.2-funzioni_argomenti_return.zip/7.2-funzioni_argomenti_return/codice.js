/*
 * Introduzione a Javascript
 * Argomenti e valori di ritorno
 *
 * Disponibile su devACADEMY.it
 */

function somma(op1, op2)
{
	somma = op1+op2;
	return somma;
}

function tabellina(x)
{
	for(i=1; i<=10; i++)
		document.write(i*x+"<br>");
}

var risultato=somma(5, 7);
document.write(risultato);

//tabellina(9);