/*
 * Introduzione a Javascript
 * Esempio riepilogativo: “Creare una libreria di funzioni”
 *
 * Disponibile su devACADEMY.it
 */

var lato1=5;
var lato2=8;

var area=areaRettangolo(lato1, lato2);

document.write("Area pari a "+area+"<br>");

var base=5;
var altezza=8;

var areaTri=areaTriangolo(base, altezza);

document.write("Area triangolo pari a "+areaTri+"<br>");