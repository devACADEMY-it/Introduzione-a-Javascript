/*
 * Introduzione a Javascript
 * do…while
 *
 * Disponibile su devACADEMY.it
 */

var ind=10;

do
{
	document.write(ind+"<br>");
	ind--;
}
while(ind>10);