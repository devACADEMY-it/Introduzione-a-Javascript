/*
 * Introduzione a Javascript
 * Operatore ternario
 *
 * Disponibile su devACADEMY.it
 */

var media=4;

var messaggio=
(media>=6)
? (document.write( "Promosso!<br>" ),
 document.write( "Complimenti!<br>" ),
 "Media del "+media
)
:(document.write( "Bocciato!<br>" ),
  "Purtroppo media non sufficiente"
 );

document.write( messaggio );

//var messaggio= (media>=6)?"Promosso":"Bocciato";

//document.write( messaggio );