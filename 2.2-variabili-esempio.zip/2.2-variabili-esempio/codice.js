/*
 * Introduzione a Javascript
 * Dichiarazione e assegnazione di variabili
 *
 * Disponibile su devACADEMY.it
 */

"use strict"
var valore=5;
const MAX=10;
document.write("Valore = "+valore);
document.write("<br>");
document.write("Costante = "+MAX);