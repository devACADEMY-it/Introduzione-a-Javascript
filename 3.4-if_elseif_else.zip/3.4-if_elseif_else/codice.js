/*
 * Introduzione a Javascript
 * If: tutte le possibilità
 *
 * Disponibile su devACADEMY.it
 */

var voto1=5;
var voto2=2;
var voto3=6;

var media=(voto1+voto2+voto3)/3;

if (media>=8)
	document.write("Complimenti, promosso con ottimi voti <br>");
else if (media>=6)
	document.write("Promosso con media "+media+"<br>");
else if (media>=5)
	document.write("Bocciato ma sei stato sfortunato <br>");
else
	document.write("Mi dispiace sei bocciato <br>");

document.write("Fine programma");