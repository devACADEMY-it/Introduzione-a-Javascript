/*
 * Introduzione a Javascript
 * for
 *
 * Disponibile su devACADEMY.it
 */

for (ind=10; ind>0; ind-=2)
{
	document.write(ind+"<br>");
}