/*
 * Introduzione a Javascript
 * Esempio riepilogo: “Numeri di Fibonacci”
 *
 * Disponibile su devACADEMY.it
 */

var corrente=1;
var precedente=1;
var quanti=10;

document.write(precedente+"<br>");
document.write(corrente+"<br>");

for (ind=1; ind<=quanti; ind++)
{
	nuovo=corrente+precedente;
	precedente=corrente;
	corrente=nuovo;

	document.write(nuovo+"<br>");
}
document.write("Fine<br>");