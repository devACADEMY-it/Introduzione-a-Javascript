/*
 * Introduzione a Javascript
 * If ed if…else
 *
 * Disponibile su devACADEMY.it
 */

var voto1=8.5;
var voto2=5;
var voto3=7;

var media=(voto1+voto2+voto3)/3;

if (media>=6)
	document.write("Promosso con media "+media+"<br>");
else
	document.write("Mi dispiace sei bocciato <br>");

document.write("Fine programma");