/*
 * Introduzione a Javascript
 * While
 *
 * Disponibile su devACADEMY.it
 */

var ind=10;

while(ind>=1)
{
	document.write(ind+"<br>");
	ind--;
}